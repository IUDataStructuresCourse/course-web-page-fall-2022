// Imports for the parameters of flood

import java.lang.reflect.Array;
import java.util.*;

public class Flood {

    public static void flood(WaterColor color,
                             LinkedList<Coord> flooded_list,
                             Tile[][] tiles,
                             Integer board_size) {
	// TODO
    }

}
